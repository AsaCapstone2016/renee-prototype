let FB_VERIFY_TOKEN = 'this_is_my_verify_token';
let FB_PAGE_TOKEN = 'EAAZAUVmiVNTYBANNKrSZCFxj0eZBwCpIhcyRQgKWdtApBEZCc3EuqC3TOqO9g9ktCBwglofZCdRasIbX77geyiM3PpUfLGsdhja7nPQZBCP8VBq8Ca66F2TFFX9IdodNyZAZCRNxQsL85eO40XByMdd3Mlj9zSSXg5caI4hMdZCmLVAZDZD';
let WIT_TOKEN = 'IMFOOKOP3BXAK5MJHCST6JWWWLHOSY3W';
// testing api gateway GET: hub.mode=subscribe&hub.verify_token=this_is_my_verify_token&hub.challenge=1